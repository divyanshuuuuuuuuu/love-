# For Srishti 🌸

A romantic interactive website created for Srishti.

## Features

- 8-page interactive story
- Beautiful animations and effects
- Background music toggle
- Special song on the final page
- Responsive design

## How to Run

Simply open `index.html` in a web browser or serve the directory with a local server.

## Technologies Used

- HTML5
- CSS3
- JavaScript (ES6+)
- Web Audio API

Made with ❤️ for Srishti
